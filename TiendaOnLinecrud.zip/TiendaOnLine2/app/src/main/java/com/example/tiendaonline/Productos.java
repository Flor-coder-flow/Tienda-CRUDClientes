package com.example.tiendaonline;

public class Productos {
    private String id_producto;
    private String producto;
    private String imagenPath;
    private String detalle;
    private String precio;

    public Productos(String id_producto, String producto, String imagenPath, String detalle, String precio) {
        this.id_producto = id_producto;
        this.producto = producto;
        this.imagenPath = imagenPath;
        this.detalle = detalle;
        this.precio = precio;
    }

    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getImagenPath() {
        return imagenPath;
    }

    public void setImagenPath(String imagenPath) {
        this.imagenPath = imagenPath;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }
}
