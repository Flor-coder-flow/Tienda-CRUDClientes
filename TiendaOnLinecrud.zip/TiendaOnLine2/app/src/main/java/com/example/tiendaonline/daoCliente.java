package com.example.tiendaonline;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class daoCliente {
    SQLiteDatabase cx;
    ArrayList<Cliente> lista=new ArrayList<Cliente>();
    Cliente c;
    Context ct;
    String nombreBD = "BDClientes";
    String tabla = "create table if not exists cliente(id integer primary key autoincrement, nombre text, telefono text, email text, edad integer)";

    public daoCliente(Context c) {
        this.ct = c;
        cx = c.openOrCreateDatabase(nombreBD, c.MODE_PRIVATE, null);
        cx.execSQL(tabla);
    }

    public boolean insertar(Cliente c) {
        ContentValues contenedor=new ContentValues();
        contenedor.put("nombre", c.getNombre());
        contenedor.put("telefono", c.getTelefono());
        contenedor.put("email", c.getEmail());
        contenedor.put("edad", c.getEdad());
        return (cx.insert("cliente",null,contenedor))>0;
    }
    public boolean editar(Cliente c) {
        ContentValues contenedor=new ContentValues();
        contenedor.put("nombre", c.getNombre());
        contenedor.put("telefono", c.getTelefono());
        contenedor.put("email", c.getEmail());
        contenedor.put("edad", c.getEdad());
        return (cx.update("cliente",contenedor,"id="+c.getId(),null))>0;
    }
    public boolean eliminar(int id) {
        return (cx.delete("cliente","id="+id,null))>0;
    }
    public ArrayList<Cliente> verTodos() {
        lista.clear();
        Cursor cursor=cx.rawQuery("select * from contacto", null);

        if(cursor!=null &&cursor.getCount()>0) {
            cursor.moveToFirst();
            do{
                lista.add(new Cliente(cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getInt(4)));

            }while (cursor.moveToNext());

        }

        return lista;
    }

    public Cliente verUno(int posicion){
        Cursor cursor=cx.rawQuery("select * from contacto", null);
        cursor.moveToPosition(posicion);
        c=new Cliente(cursor.getInt(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getInt(4));

        return c;
    }
    
}
